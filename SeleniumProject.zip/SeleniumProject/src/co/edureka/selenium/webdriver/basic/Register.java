package co.edureka.selenium.webdriver.basic;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Register {

	public static WebDriver driver = null;

	public static void main(String[] args) {
	   System.setProperty("webdriver.chrome.driver", "C:\\Users\\Kitiki Masemola\\Downloads\\chromedriver_win32\\chromedriver.exe");
	   WebDriver driver= new ChromeDriver();
	   driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.navigate().to("http://demo.guru99.com/test/newtours/index.php");
		
		driver.findElement(By.xpath("/html/body/div[2]/table/tbody/tr/td[2]/table/tbody/tr[2]/td/table/tbody/tr/td[2]/a")).click();
		Thread.sleep(4000);
		
		driver.findElement(By.name("firstName")).sendKeys("Seipelo");
		driver.findElement(By.name("lastName")).sendKeys("Masemola");
		driver.findElement(By.name("phone")).sendKeys("0658584113");
		driver.findElement(By.name(" ")).sendKeys("Seipelo");
		driver.findElement(By.name("userName")).sendKeys("kitiki203@gmail.com");
		driver.findElement(By.name("Address")).sendKeys("59 woodlands Avenue");
		driver.findElement(By.name("City")).sendKeys("Johannesburg");
	    driver.findElement(By.name("postalCode")).sendKeys("9194");
		driver.findElement(By.name("email")).sendKeys("kitiki203@gmail.com");
		driver.findElement(By.name("password")).sendKeys("Masemola@98");
		driver.findElement(By.name("confirmPassword")).sendKeys("Masemola@98");
		
		
		
	}
}
